import { LRUCache } from 'lru-cache';

const cache = new LRUCache({
  max: 100,
  ttl: 1000 * 60 * 10, // 10分钟
});

export function cacheMiddleware(req, res, next) {
  const key = req.originalUrl;
  
  // 跳过某些请求的缓存
  if (req.method !== 'GET' || req.path === '/health') {
    return next();
  }
  
  const cached = cache.get(key);
  if (cached) {
    res.set(cached.headers);
    return res.send(cached.body);
  }
  
  // 劫持 send 方法缓存响应
  const originalSend = res.send;
  res.send = function(body) {
    if (res.statusCode === 200) {
      cache.set(key, {
        body,
        headers: {
          'Content-Type': res.get('Content-Type'),
          'X-Cached': 'true'
        }
      });
    }
    originalSend.call(this, body);
  };
  
  next();
}