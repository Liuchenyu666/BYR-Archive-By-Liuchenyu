const requestCounts = new Map();

export function rateLimit(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  const windowMs = 60000; // 1分钟
  const maxRequests = 100; // 最大请求数
  
  if (!requestCounts.has(ip)) {
    requestCounts.set(ip, []);
  }
  
  const requests = requestCounts.get(ip);
  const windowStart = now - windowMs;
  
  // 清理过期的请求记录
  const validRequests = requests.filter(time => time > windowStart);
  requestCounts.set(ip, validRequests);
  
  if (validRequests.length >= maxRequests) {
    return res.status(429).json({
      error: 'Too many requests',
      message: 'Rate limit exceeded. Please try again later.'
    });
  }
  
  validRequests.push(now);
  next();
}