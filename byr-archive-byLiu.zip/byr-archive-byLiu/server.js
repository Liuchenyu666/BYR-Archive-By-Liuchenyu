import express from 'express';
import compression from 'compression';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const REGISTRY = process.env.REGISTRY || 'https://registry.npmjs.org';

// 中间件
app.use(compression());
app.use(express.json());

// 简单的根路径响应
app.get('/', (req, res) => {
  res.json({
    service: 'BYR jsDelivr CDN',
    description: 'A jsDelivr-like service for BYR Archive',
    registry: REGISTRY,
    status: 'Running'
  });
});

// 健康检查
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString()
  });
});

// 启动服务
app.listen(PORT, () => {
  console.log(`BYR jsDelivr service running on port ${PORT}`);
  console.log(`Registry: ${REGISTRY}`);
});