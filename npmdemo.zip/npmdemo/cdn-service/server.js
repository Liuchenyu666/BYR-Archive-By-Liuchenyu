import express from 'express';
import axios from 'axios';
import mime from 'mime-types';
import { LRUCache } from 'lru-cache';
import compression from 'compression';
import crypto from 'crypto';

import { fetchNpmPackage, resolveVersion } from './lib/npm-fetcher.js';
import { getCache, setCache } from './lib/cache-manager.js';
import { rateLimit } from './middleware/rate-limit.js';
import { compressMiddleware } from './middleware/compression.js';

const app = express();
const PORT = process.env.PORT || 3000;

// 中间件
app.use(compression());
app.use(rateLimit);
app.use(compressMiddleware);

// 提供静态文件服务（用于本地测试）
app.use('/static', express.static('public'));

// 主要路由 - 处理NPM包请求
// 修复路由参数处理
app.get('/npm/:package/:version/*', async (req, res) => {
  try {
    const packageName = req.params.package;
    const version = req.params.version;
    const filePath = req.params[0]; // 通配符匹配的部分

    console.log(`Request for: ${packageName}@${version}/${filePath}`);

    // 生成缓存key
    const cacheKey = `${packageName}@${version}/${filePath}`;
    
    // 检查缓存
    let fileContent = getCache(cacheKey);
    if (fileContent) {
      console.log('Serving from cache');
      return sendFileResponse(res, fileContent, filePath);
    }

    // 解析版本（处理latest等标签）
    const resolvedVersion = await resolveVersion(packageName, version);
    
    // 获取文件内容
    fileContent = await fetchNpmPackage(packageName, resolvedVersion, filePath);
    
    if (!fileContent) {
      return res.status(404).json({ 
        error: 'File not found',
        package: packageName,
        version: resolvedVersion,
        file: filePath
      });
    }

    // 存储到缓存
    setCache(cacheKey, fileContent);
    
    // 发送响应
    sendFileResponse(res, fileContent, filePath);
    
  } catch (error) {
    console.error('Error processing request:', error);
    res.status(500).json({ 
      error: 'Internal server error',
      message: error.message 
    });
  }
});

// GitHub文件服务路由
app.get('/gh/:user/:repo/:branch/*', async (req, res) => {
  try {
    const user = req.params.user;
    const repo = req.params.repo;
    const branch = req.params.branch;
    const filePath = req.params[0];

    const cacheKey = `gh:${user}/${repo}@${branch}/${filePath}`;
    
    // 检查缓存
    let fileContent = getCache(cacheKey);
    if (fileContent) {
      return sendFileResponse(res, fileContent, filePath);
    }

    // 从GitHub获取文件
    const githubUrl = `https://raw.githubusercontent.com/${user}/${repo}/${branch}/${filePath}`;
    const response = await axios.get(githubUrl, { 
      responseType: 'arraybuffer',
      timeout: 10000
    });

    fileContent = response.data;
    
    // 存储到缓存
    setCache(cacheKey, fileContent);
    
    sendFileResponse(res, fileContent, filePath);
    
  } catch (error) {
    if (error.response && error.response.status === 404) {
      res.status(404).json({ error: 'File not found' });
    } else {
      console.error('GitHub fetch error:', error);
      res.status(500).json({ error: 'Failed to fetch from GitHub' });
    }
  }
});

// 健康检查端点
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// 根路径
app.get('/', (req, res) => {
  res.json({
    name: 'Simple CDN Service',
    description: 'A jsDelivr-like CDN service',
    endpoints: {
      npm: '/npm/:package/:version/:filepath',
      github: '/gh/:user/:repo/:branch/:filepath'
    },
    example: {
      npm: '/npm/jquery/3.6.0/dist/jquery.min.js',
      github: '/gh/jquery/jquery/main/dist/jquery.min.js'
    }
  });
});

// 404处理
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// 错误处理中间件
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// 发送文件响应的辅助函数
function sendFileResponse(res, content, filePath) {
  const contentType = mime.lookup(filePath) || 'application/octet-stream';
  
  res.set({
    'Content-Type': contentType,
    'Cache-Control': 'public, max-age=31536000', // 1年缓存
    'ETag': generateETag(content)
  });
  
  res.send(content);
}

// 生成ETag
function generateETag(content) {
  const hash = crypto.createHash('md5')
    .update(content)
    .digest('hex');
  return `"${hash}"`;
}

// 启动服务
app.listen(PORT, () => {
  console.log(`CDN service running on port ${PORT}`);
});
