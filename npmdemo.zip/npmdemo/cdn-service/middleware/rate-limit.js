import { LRUCache } from 'lru-cache';

// IP请求计数器
const ipRequests = new LRUCache({
  max: 10000,
  ttl: 60 * 1000 // 1分钟窗口
});

/**
 * 简单的速率限制中间件
 */
function rateLimit(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress;
  const currentTime = Date.now();
  
  // 获取IP的请求记录
  const requests = ipRequests.get(ip) || [];
  
  // 过滤出1分钟内的请求
  const recentRequests = requests.filter(time => currentTime - time < 60000);
  
  // 检查是否超过限制（每分钟100个请求）
  if (recentRequests.length >= 100) {
    return res.status(429).json({
      error: 'Too many requests',
      message: 'Rate limit exceeded. Please try again later.'
    });
  }
  
  // 记录当前请求
  recentRequests.push(currentTime);
  ipRequests.set(ip, recentRequests);
  
  next();
}

export {
  rateLimit
};
