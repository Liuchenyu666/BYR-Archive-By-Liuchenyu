
import zlib from 'zlib';

/**
 * 自定义压缩中间件
 */
function compressMiddleware(req, res, next) {
  const acceptEncoding = req.headers['accept-encoding'] || '';
  
  // 保存原始的send方法
  const originalSend = res.send;
  
  // 重写send方法以支持压缩
  res.send = function(data) {
    // 确定内容编码
    let encoding = null;
    let compressedData = data;
    
    if (typeof data === 'string' || Buffer.isBuffer(data)) {
      // 根据Accept-Encoding选择压缩算法
      if (acceptEncoding.includes('br')) {
        encoding = 'br';
        compressedData = zlib.brotliCompressSync(data);
      } else if (acceptEncoding.includes('gzip')) {
        encoding = 'gzip';
        compressedData = zlib.gzipSync(data);
      }
      
      // 设置压缩相关的响应头
      if (encoding) {
        res.set('Content-Encoding', encoding);
      }
    }
    
    // 调用原始send方法
    originalSend.call(this, compressedData);
  };
  
  next();
}

export { compressMiddleware };